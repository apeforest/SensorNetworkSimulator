//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Beacon.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BEACON_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_Num                         1001
#define IDC_Ran                         1002
#define IDC_Per                         1003
#define IDC_OutFile                     1004
#define IDC_NumH                        1005
#define IDC_RanH                        1006
#define IDC_PerH                        1007
#define IDC_Trials                      1008
#define IDC_NumL                        1009
#define IDC_RanL                        1010
#define IDC_PerL                        1011
#define IDC_Calc                        1012
#define IDC_Rand                        1013
#define IDC_Progress                    1015
#define IDC_Status                      1017
#define IDC_Picture                     1018
#define IDC_Step                        1019
#define IDC_NumSteps                    1020
#define IDC_chkNS                       1021
#define IDC_chkRS                       1022
#define IDC_chkPS                       1023
#define IDC_chkFP                       1024
#define IDC_chkMaple                    1025
#define IDC_Input                       1026
#define IDC_Refresh                     1027
#define IDC_InFile                      1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
