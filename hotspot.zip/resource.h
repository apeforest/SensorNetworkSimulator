//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HotSpot.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HOTSPOT_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_Picture                     1001
#define IDC_New                         1002
#define IDC_Border                      1003
#define IDC_Refresh                     1004
#define IDC_BkgR                        1005
#define IDC_BkgG                        1006
#define IDC_BkgB                        1007
#define IDC_LowR                        1008
#define IDC_LowG                        1009
#define IDC_LowB                        1010
#define IDC_MedR                        1011
#define IDC_MedG                        1012
#define IDC_MedB                        1013
#define IDC_HighR                       1014
#define IDC_HighG                       1015
#define IDC_HighB                       1016
#define IDC_Sleep                       1017
#define IDC_Radius                      1018
#define IDC_NumSensors                  1019
#define IDC_SleepR                      1020
#define IDC_SleepG                      1021
#define IDC_SleepB                      1022
#define IDC_EdgeR                       1023
#define IDC_EdgeG                       1024
#define IDC_EdgeB                       1025
#define IDC_SensorSize                  1026
#define IDC_GradientEdges               1027
#define IDC_EdgeBright                  1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
