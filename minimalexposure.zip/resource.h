//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Exposure.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EXPOSURE_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_Graph                       1000
#define IDC_Generate                    1001
#define IDC_N                           1002
#define IDC_u                           1003
#define IDC_P                           1004
#define IDC_GridSize                    1005
#define IDC_OutFile                     1006
#define IDC_SX                          1007
#define IDC_SY                          1008
#define IDC_EX                          1009
#define IDC_EY                          1010
#define IDC_Rand                        1012
#define IDC_Triangle                    1013
#define IDC_Rectangle                   1014
#define IDC_Hexagon                     1015
#define IDC_Length                      1016
#define IDC_Status                      1017
#define IDC_Progress                    1018
#define IDC_GridAccuracy                1019
#define IDC_Grid                        1020
#define IDC_Refresh                     1021
#define IDC_Refine                      1022
#define IDC_RefZone                     1023
#define IDC_PathV                       1024
#define IDC_InputFile                   1025
#define IDC_Input                       1026
#define IDC_Output                      1027
#define IDC_PathCost                    1028
#define IDC_ShowVoronoi                 1029
#define IDC_PLen                        1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
